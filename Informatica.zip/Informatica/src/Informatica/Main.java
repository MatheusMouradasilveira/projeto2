package Informatica;

public class Main {

    public static void main(String[] args) {
        Interface i1 = new Interface();
        i1.setVisible(true);
    }
}